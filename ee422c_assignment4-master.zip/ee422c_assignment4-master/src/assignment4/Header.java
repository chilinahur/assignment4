package assignment4;
/* CRITTERS <MyClass.java>
 * EE422C Project 4 submission by
 * 
 * Sriram Chilukuri
 * smc4474
 * 16445
 * Yousef Abdelrazzaq
 * Yja87
 * 16445
 * Slip days used: <1>
 * Fall 2016
 */
